// import { Injectable} from '@angular/core';
// import { AngularFireDatabase } from '@angular/fire/database';
// import { AngularFireAuth } from '@angular/fire/auth';
// import * as firebase from 'firebase';

// import 'rxjs/add/operator/take';
// import { BehaviorSubject } from 'rxjs'

// @Injectable()
// export class MessagingService {

//   messaging = firebase.messaging()
//   currentMessage = new BehaviorSubject(null)

//   constructor(private db: AngularFireDatabase, private afAuth: AngularFireAuth) { }


//   updateToken(token:any) {
//     this.afAuth.authState.take(1).subscribe((user:any) => {
//       if (!user) return;

//       const data = { [user.uid]: token }
//       this.db.object('fcmTokens/').update(data)
//     })
//   }

//   getPermission() {
//     this.messaging.requestPermission()
//     .then(() => {
//       console.log('Notification permission granted.');
//       return this.messaging.getToken()
//     })
//     .then((token:any) => {
//       console.log(token)
//       this.updateToken(token)
//     })
//     .catch((err:any) => {
//       console.log('Unable to get permission to notify.', err);
//     });
//   }

//   receiveMessage() {
    
//      this.messaging.onMessage((payload:any) => {
//       console.log("Message received. ", payload);
//       this.currentMessage.next(payload)
//     });

//   }
// }
