import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisclaimerPageComponent } from './disclaimer-page.component';

describe('DisclaimerPageComponent', () => {
  let component: DisclaimerPageComponent;
  let fixture: ComponentFixture<DisclaimerPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisclaimerPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisclaimerPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
